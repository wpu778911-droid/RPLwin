from typing import Dict, Optional, Sequence, Tuple

import numpy as np
from gym import spaces

from gops.env.env_gen_ocp.pyth_base import Context, ContextState, Env, Robot, State

STEER_LIMIT = np.deg2rad(170.0)
STEER_RATE_MAX = np.deg2rad(120.0)
WHEEL_ACC_MAX = 1.0

BALL_SPEED = 0.1
RECT_W = 2.5
RECT_H = 1.5
CORNER_R = 0.3
WHEEL_POS = {
    "FR": (+0.24, -0.175),
    "RR": (-0.24, -0.175),
    "RL": (-0.24, +0.175),
    "FL": (+0.24, +0.175),
}
WHEEL_ORDER = ("FR", "RR", "RL", "FL")


def wrap_to_pi(angle: float) -> float:
    return (angle + np.pi) % (2.0 * np.pi) - np.pi


def clip(x: np.ndarray, low: np.ndarray, high: np.ndarray) -> np.ndarray:
    return np.minimum(np.maximum(x, low), high)


def _rounded_rect_perimeter() -> float:
    straight_x = 2.0 * (RECT_W - CORNER_R)
    straight_y = 2.0 * (RECT_H - CORNER_R)
    arc = 0.5 * np.pi * CORNER_R
    return 2.0 * (straight_x + straight_y) + 4.0 * arc


def _rounded_rect_pos_vel(s: float) -> Tuple[float, float, float, float]:
    straight_x = 2.0 * (RECT_W - CORNER_R)
    straight_y = 2.0 * (RECT_H - CORNER_R)
    arc = 0.5 * np.pi * CORNER_R

    if s < straight_x:
        x = -RECT_W + CORNER_R + s
        y = -RECT_H
        dx, dy = BALL_SPEED, 0.0
        return x, y, dx, dy
    s -= straight_x

    if s < arc:
        theta = -0.5 * np.pi + s / CORNER_R
        cx, cy = RECT_W - CORNER_R, -RECT_H + CORNER_R
        x = cx + CORNER_R * np.cos(theta)
        y = cy + CORNER_R * np.sin(theta)
        dx = BALL_SPEED * (-np.sin(theta))
        dy = BALL_SPEED * (np.cos(theta))
        return x, y, dx, dy
    s -= arc

    if s < straight_y:
        x = RECT_W
        y = -RECT_H + CORNER_R + s
        dx, dy = 0.0, BALL_SPEED
        return x, y, dx, dy
    s -= straight_y

    if s < arc:
        theta = 0.0 + s / CORNER_R
        cx, cy = RECT_W - CORNER_R, RECT_H - CORNER_R
        x = cx + CORNER_R * np.cos(theta)
        y = cy + CORNER_R * np.sin(theta)
        dx = BALL_SPEED * (-np.sin(theta))
        dy = BALL_SPEED * (np.cos(theta))
        return x, y, dx, dy
    s -= arc

    if s < straight_x:
        x = RECT_W - CORNER_R - s
        y = RECT_H
        dx, dy = -BALL_SPEED, 0.0
        return x, y, dx, dy
    s -= straight_x

    if s < arc:
        theta = 0.5 * np.pi + s / CORNER_R
        cx, cy = -RECT_W + CORNER_R, RECT_H - CORNER_R
        x = cx + CORNER_R * np.cos(theta)
        y = cy + CORNER_R * np.sin(theta)
        dx = BALL_SPEED * (-np.sin(theta))
        dy = BALL_SPEED * (np.cos(theta))
        return x, y, dx, dy
    s -= arc

    if s < straight_y:
        x = -RECT_W
        y = RECT_H - CORNER_R - s
        dx, dy = 0.0, -BALL_SPEED
        return x, y, dx, dy
    s -= straight_y

    theta = np.pi + s / CORNER_R
    cx, cy = -RECT_W + CORNER_R, -RECT_H + CORNER_R
    x = cx + CORNER_R * np.cos(theta)
    y = cy + CORNER_R * np.sin(theta)
    dx = BALL_SPEED * (-np.sin(theta))
    dy = BALL_SPEED * (np.cos(theta))
    return x, y, dx, dy


def ball_rect_traj(t: float, t_total: float) -> Tuple[float, float]:
    period = _rounded_rect_perimeter() / BALL_SPEED
    s = (t % period) * BALL_SPEED
    x, y, _, _ = _rounded_rect_pos_vel(s)
    return x, y


def ball_rect_vel(t: float, t_total: float) -> Tuple[float, float]:
    period = _rounded_rect_perimeter() / BALL_SPEED
    s = (t % period) * BALL_SPEED
    _, _, dx, dy = _rounded_rect_pos_vel(s)
    return dx, dy


def compute_scan_follow_target(
    bx: float,
    by: float,
    bdx: float,
    bdy: float,
    follow_dist: float,
) -> Tuple[float, float]:
    # Right-side normal of target velocity direction: n_r = [sin(phi), -cos(phi)]
    speed = np.hypot(bdx, bdy)
    if speed > 1e-6:
        ux, uy = bdx / speed, bdy / speed
    else:
        ux, uy = 1.0, 0.0
    n_r = np.array([uy, -ux], dtype=np.float32)
    rx = bx + follow_dist * n_r[0]
    ry = by + follow_dist * n_r[1]
    return float(rx), float(ry)


def world_to_body(px: float, py: float, yaw: float, xw: float, yw: float) -> Tuple[float, float]:
    dx = xw - px
    dy = yw - py
    c = np.cos(yaw)
    s = np.sin(yaw)
    xb = c * dx + s * dy
    yb = -s * dx + c * dy
    return float(xb), float(yb)


def huber_loss(x: float, delta: float = 0.25) -> float:
    ax = abs(float(x))
    if ax <= delta:
        return 0.5 * ax * ax
    return delta * (ax - 0.5 * delta)


class ToRwheelsimRobot(Robot):
    def __init__(
        self,
        dt: float,
        v_wheel_max: float,
        steer_rate_max: Optional[float],
        wheel_acc_max: Optional[float],
        w_max: float,
        v_max: float,
        a_max: float,
        lsq_reg: float = 1e-4,
    ):
        self.dt = dt
        self.v_wheel_max = v_wheel_max
        self.steer_rate_max = STEER_RATE_MAX if steer_rate_max is None else steer_rate_max
        self.wheel_acc_max = WHEEL_ACC_MAX if wheel_acc_max is None else wheel_acc_max
        self.w_max = w_max
        self.v_max = v_max
        self.a_max = a_max
        self.lsq_reg = lsq_reg
        self.state_space = spaces.Box(
            low=np.array([-np.inf, -np.inf, -np.pi], dtype=np.float32),
            high=np.array([np.inf, np.inf, np.pi], dtype=np.float32),
            dtype=np.float32,
        )
        self.action_space = spaces.Box(
            low=np.array([-self.steer_rate_max, -self.wheel_acc_max] * 4, dtype=np.float32),
            high=np.array([self.steer_rate_max, self.wheel_acc_max] * 4, dtype=np.float32),
            dtype=np.float32,
        )
        self._steer = {name: 0.0 for name in WHEEL_ORDER}
        self._speed = {name: 0.0 for name in WHEEL_ORDER}
        self._prev_steer = {name: 0.0 for name in WHEEL_ORDER}
        self._vel_world = np.zeros(2, dtype=np.float32)
        self._w_body = 0.0
        self.last_flip_count = 0
        self.last_flip_triggered = False

    @property
    def vel_world(self) -> np.ndarray:
        return self._vel_world

    @property
    def w_body(self) -> float:
        return self._w_body

    def reset(self, state: np.ndarray) -> np.ndarray:
        self._steer = {name: 0.0 for name in WHEEL_ORDER}
        self._speed = {name: 0.0 for name in WHEEL_ORDER}
        self._prev_steer = {name: 0.0 for name in WHEEL_ORDER}
        self._vel_world = np.zeros(2, dtype=np.float32)
        self._w_body = 0.0
        self._step_count = 0
        self.last_flip_count = 0
        self.last_flip_triggered = False
        return super().reset(state)

    def _maybe_flip(self, steer: float, speed: float, prev_steer: float) -> Tuple[float, float, bool]:
        # Traditional steering-limit shell is kept as a safety guard.
        # RL is rewarded to reduce dependence on this shell rather than remove it.
        steer = wrap_to_pi(steer)
        steer = float(np.clip(steer, -STEER_LIMIT, STEER_LIMIT))
        steer_alt = wrap_to_pi(steer + np.pi)

        margin = np.deg2rad(5.0)
        near_limit = abs(steer) > (STEER_LIMIT - margin)
        flip_cooldown_steps = int(max(1.0, 0.3 / self.dt))
        if not hasattr(self, "_flip_counter"):
            self._flip_counter = 0
        can_flip = self._flip_counter == 0
        flipped = False

        if can_flip and near_limit:
            steer = steer_alt
            speed = -speed
            self._flip_counter = flip_cooldown_steps
            flipped = True
        elif self._flip_counter > 0:
            self._flip_counter -= 1

        steer = float(np.clip(steer, -STEER_LIMIT, STEER_LIMIT))
        return steer, speed, flipped

    def step(self, action: np.ndarray) -> np.ndarray:
        action = clip(action, self.action_space.low, self.action_space.high)
        px, py, yaw = self.state
        if not hasattr(self, "_step_count"):
            self._step_count = 0
        self._step_count += 1

        flip_count = 0
        for i, name in enumerate(WHEEL_ORDER):
            d_steer = float(action[2 * i])
            d_speed = float(action[2 * i + 1])

            steer = self._steer[name] + d_steer * self.dt
            speed = self._speed[name] + d_speed * self.dt
            speed = float(np.clip(speed, -self.v_wheel_max, self.v_wheel_max))

            steer, speed, flipped = self._maybe_flip(steer, speed, self._prev_steer[name])
            if flipped:
                flip_count += 1

            self._steer[name] = steer
            self._speed[name] = speed
            self._prev_steer[name] = steer

        A_rows = []
        b_rows = []
        for name in WHEEL_ORDER:
            x_i, y_i = WHEEL_POS[name]
            steer = self._steer[name]
            speed = self._speed[name]
            c = np.cos(steer)
            s = np.sin(steer)
            A_rows.append([c, s, -c * y_i + s * x_i])
            b_rows.append(speed)

        A = np.array(A_rows, dtype=np.float32)
        b = np.array(b_rows, dtype=np.float32)
        AtA = A.T @ A + self.lsq_reg * np.eye(3, dtype=np.float32)
        Atb = A.T @ b
        vx_body, vy_body, w_body = np.linalg.solve(AtA, Atb)

        v_body_limit = 2.0 * self.v_wheel_max
        vx_body = float(np.clip(vx_body, -v_body_limit, v_body_limit))
        vy_body = float(np.clip(vy_body, -v_body_limit, v_body_limit))
        w_body = float(np.clip(w_body, -self.w_max, self.w_max))

        yaw_mid = yaw + 0.5 * w_body * self.dt
        cos_yaw = np.cos(yaw_mid)
        sin_yaw = np.sin(yaw_mid)
        vx_world = vx_body * cos_yaw - vy_body * sin_yaw
        vy_world = vx_body * sin_yaw + vy_body * cos_yaw
        vel_new = np.array([vx_world, vy_world], dtype=np.float32)
        speed_world = float(np.hypot(vel_new[0], vel_new[1]))
        if speed_world > self.v_max and speed_world > 1e-9:
            vel_new = vel_new * (self.v_max / speed_world)

        delta_v = vel_new - self._vel_world
        delta_norm = float(np.hypot(delta_v[0], delta_v[1]))
        a_limit = self.a_max * self.dt
        if delta_norm > a_limit and delta_norm > 1e-9:
            delta_v = delta_v * (a_limit / delta_norm)
        vel_new = self._vel_world + delta_v
        self._vel_world = vel_new
        self._w_body = w_body

        px_next = px + self._vel_world[0] * self.dt
        py_next = py + self._vel_world[1] * self.dt
        yaw_next = wrap_to_pi(yaw + self._w_body * self.dt)
        self.state = np.array([px_next, py_next, yaw_next], dtype=np.float32)

        self.last_flip_count = int(flip_count)
        self.last_flip_triggered = bool(flip_count > 0)
        return self.state


class BallRefContext(Context):
    def __init__(self, dt: float, t_total: float):
        self.dt = dt
        self.t_total = t_total
        self.ref_time = 0.0
        self.state = ContextState(reference=np.zeros(4, dtype=np.float32), t=0)

    def reset(self, ref_time: float = 0.0) -> ContextState[np.ndarray]:
        self.ref_time = ref_time
        bx, by = ball_rect_traj(self.ref_time, self.t_total)
        bdx, bdy = ball_rect_vel(self.ref_time, self.t_total)
        self.state = ContextState(reference=np.array([bx, by, bdx, bdy], dtype=np.float32), t=0)
        return self.state

    def step(self) -> ContextState[np.ndarray]:
        self.ref_time += self.dt
        bx, by = ball_rect_traj(self.ref_time, self.t_total)
        bdx, bdy = ball_rect_vel(self.ref_time, self.t_total)
        self.state = ContextState(reference=np.array([bx, by, bdx, bdy], dtype=np.float32), t=0)
        return self.state

    def get_zero_state(self) -> ContextState[np.ndarray]:
        return ContextState(reference=np.zeros(4, dtype=np.float32), t=0)


class ToRwheelsimSeqScanEnv(Env):
    termination_penalty = 50.0
    metadata = {"render.modes": ["human", "rgb_array"]}

    def __init__(
        self,
        *,
        dt: float = 0.05,
        t_total: float = 30.0,
        episode_steps: int = 1500,
        follow_dist: float = 0.3,
        v_wheel_max: float = 0.3,
        w_max: float = 1.5,
        v_max: float = 0.3,
        a_max: float = 0.3,
        steer_rate_max: Optional[float] = None,
        wheel_acc_max: Optional[float] = None,
        action_horizon: int = 3,
        safety_margin_ratio: float = 0.12,
        **kwargs,
    ):
        self.robot = ToRwheelsimRobot(
            dt=dt,
            v_wheel_max=v_wheel_max,
            steer_rate_max=steer_rate_max,
            wheel_acc_max=wheel_acc_max,
            w_max=w_max,
            v_max=v_max,
            a_max=a_max,
        )
        self.context = BallRefContext(dt=dt, t_total=t_total)
        self.dt = dt
        self.t_total = t_total
        self.follow_dist = follow_dist
        self.max_episode_steps = int(episode_steps)
        self.v_max = float(v_max)
        self.w_max = float(w_max)
        self.action_horizon = int(action_horizon)
        self.action_dim_per_step = 8
        if self.action_horizon != 3:
            raise ValueError("This environment is designed for action_horizon=3.")

        # Obs layout (32D):
        # A(4): B and R in body frame
        # B(1): yaw tracking error from reference target direction
        # C(2): target velocity in body frame
        # D(3): chassis vx, vy, omega (body)
        # E(6): future R1/R2/R3 in body frame
        # F(16): per-wheel [cos(steer), sin(steer), norm_speed, margin]
        obs_dim = 32
        self.observation_space = spaces.Box(
            low=np.array([-np.inf] * obs_dim, dtype=np.float32),
            high=np.array([np.inf] * obs_dim, dtype=np.float32),
            dtype=np.float32,
        )

        low_step = np.array([-self.robot.steer_rate_max, -self.robot.wheel_acc_max] * 4, dtype=np.float32)
        high_step = np.array([self.robot.steer_rate_max, self.robot.wheel_acc_max] * 4, dtype=np.float32)
        self.action_space = spaces.Box(
            low=np.tile(low_step, self.action_horizon),
            high=np.tile(high_step, self.action_horizon),
            dtype=np.float32,
        )

        self.init_dist = 1.0
        self._safety_margin_ratio = float(safety_margin_ratio)
        self._debug_reward_terms: Dict[str, float] = {}
        self._last_exec_action = np.zeros(8, dtype=np.float32)
        self._prev_ref_pos_err = 0.0
        self._prev_ref_vel_err = 0.0
        self._prev_yaw_err = 0.0
        self._yaw_ref_prev = 0.0
        self._prev_w_body = 0.0
        self._prev_speed_sign = np.zeros(4, dtype=np.float32)
        self._flip_total = 0
        self._last_mode_alpha_1 = 0.5
        self._last_mode_alpha_2 = 0.5
        self._elapsed_steps = 0
        self.seed()

    def _split_action(self, action: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        action = np.asarray(action, dtype=np.float32).reshape(-1)
        action = clip(action, self.action_space.low, self.action_space.high)
        action_seq = action.reshape(self.action_horizon, self.action_dim_per_step)
        # Actor outputs 3-step action sequence (24D), env executes only the first 8D now.
        # The remaining planned actions are not executed here, but used for smoothness regularization.
        action_exec = action_seq[0].copy()
        return action_seq, action_exec

    def _target_and_ref_world(self) -> Tuple[float, float, float, float, float, float, float]:
        px, py, yaw = self.robot.state
        bx, by, bdx, bdy = self.context.state.reference
        rx, ry = compute_scan_follow_target(bx, by, bdx, bdy, self.follow_dist)
        yaw_ref = np.arctan2(by - py, bx - px)
        return float(bx), float(by), float(bdx), float(bdy), float(rx), float(ry), float(yaw_ref)

    def _task_geometry(self) -> Dict[str, float]:
        px, py, yaw = self.robot.state
        bx, by, bdx, bdy = self.context.state.reference
        speed = float(np.hypot(bdx, bdy))
        if speed > 1e-6:
            ux, uy = bdx / speed, bdy / speed
        else:
            ux, uy = 1.0, 0.0
        t_hat = np.array([ux, uy], dtype=np.float32)
        n_r = np.array([uy, -ux], dtype=np.float32)
        rx = float(bx + self.follow_dist * n_r[0])
        ry = float(by + self.follow_dist * n_r[1])
        x_R_body, y_R_body = world_to_body(px, py, yaw, rx, ry)
        x_B_body, y_B_body = world_to_body(px, py, yaw, bx, by)
        c = np.cos(yaw)
        s = np.sin(yaw)
        v_ref_bx = float(c * bdx + s * bdy)
        v_ref_by = float(-s * bdx + c * bdy)
        v_cur_bx = float(c * self.robot.vel_world[0] + s * self.robot.vel_world[1])
        v_cur_by = float(-s * self.robot.vel_world[0] + c * self.robot.vel_world[1])
        ref_pos_err = float(np.hypot(x_R_body, y_R_body) / max(self.follow_dist, 1e-6))
        ref_vel_err = float(np.hypot(v_cur_bx - v_ref_bx, v_cur_by - v_ref_by) / max(self.v_max, 1e-6))
        yaw_face_raw = float(np.arctan2(by - py, bx - px))
        if not hasattr(self, "_yaw_ref_prev"):
            self._yaw_ref_prev = yaw_face_raw
        speed_scale = float(np.clip(speed / max(self.v_max, 1e-6), 0.0, 1.0))
        beta = 0.12 + 0.18 * speed_scale
        dyaw = wrap_to_pi(yaw_face_raw - self._yaw_ref_prev)
        yaw_face = float(wrap_to_pi(self._yaw_ref_prev + beta * dyaw))
        yaw_err = float(wrap_to_pi(yaw - yaw_face))
        return {
            "bx": float(bx),
            "by": float(by),
            "bdx": float(bdx),
            "bdy": float(bdy),
            "rx": rx,
            "ry": ry,
            "x_B_body": x_B_body,
            "y_B_body": y_B_body,
            "x_R_body": x_R_body,
            "y_R_body": y_R_body,
            "v_ref_bx": v_ref_bx,
            "v_ref_by": v_ref_by,
            "v_cur_bx": v_cur_bx,
            "v_cur_by": v_cur_by,
            "ref_pos_err": ref_pos_err,
            "ref_vel_err": ref_vel_err,
            "yaw_face_raw": yaw_face_raw,
            "yaw_face": yaw_face,
            "ux": float(ux),
            "uy": float(uy),
            "nr_x": float(n_r[0]),
            "nr_y": float(n_r[1]),
        }

    def _future_ref_preview_body(self, steps: int = 3) -> np.ndarray:
        px, py, yaw = self.robot.state
        preview = []
        for k in range(1, steps + 1):
            t_k = self.context.ref_time + k * self.dt
            bx_k, by_k = ball_rect_traj(t_k, self.t_total)
            bdx_k, bdy_k = ball_rect_vel(t_k, self.t_total)
            rx_k, ry_k = compute_scan_follow_target(bx_k, by_k, bdx_k, bdy_k, self.follow_dist)
            xr_k, yr_k = world_to_body(px, py, yaw, rx_k, ry_k)
            preview.extend([xr_k, yr_k])
        return np.array(preview, dtype=np.float32)

    def _compute_wheel_metrics(self) -> Tuple[np.ndarray, np.ndarray, float, np.ndarray]:
        px, py, yaw = self.robot.state
        vx_w, vy_w = self.robot.vel_world
        c = np.cos(yaw)
        s = np.sin(yaw)
        vx_b = vx_w * c + vy_w * s
        vy_b = -vx_w * s + vy_w * c
        w_b = self.robot.w_body
        slip = []
        util = []
        margins = []
        vmax = max(self.robot.v_wheel_max, 1e-6)
        for name in WHEEL_ORDER:
            x_i, y_i = WHEEL_POS[name]
            steer = self.robot._steer[name]
            speed = self.robot._speed[name]
            wheel_vx = vx_b - w_b * y_i
            wheel_vy = vy_b + w_b * x_i
            slip_i = (-np.sin(steer) * wheel_vx + np.cos(steer) * wheel_vy) / vmax
            util_i = abs(speed) / vmax
            margin_i = (STEER_LIMIT - abs(steer)) / max(STEER_LIMIT, 1e-6)
            slip.append(float(slip_i))
            util.append(float(util_i))
            margins.append(float(margin_i))
        if abs(vx_b) < 1e-6:
            vx_b = 1e-6
        sideslip = float(np.arctan2(vy_b, vx_b))
        return (
            np.array(slip, dtype=np.float32),
            np.array(util, dtype=np.float32),
            sideslip,
            np.array(margins, dtype=np.float32),
        )

    def _get_obs(self) -> np.ndarray:
        px, py, yaw = self.robot.state
        vx_w, vy_w = self.robot.vel_world
        w_b = self.robot.w_body
        geom = self._task_geometry()
        x_B_body = geom["x_B_body"]
        y_B_body = geom["y_B_body"]
        x_R_body = geom["x_R_body"]
        y_R_body = geom["y_R_body"]
        yaw_ref = geom["yaw_face"]
        e_psi = wrap_to_pi(yaw - yaw_ref)
        v_Bx_body = geom["v_ref_bx"]
        v_By_body = geom["v_ref_by"]
        v_x_body = geom["v_cur_bx"]
        v_y_body = geom["v_cur_by"]

        preview_body = self._future_ref_preview_body(steps=3)
        _, _, _, margins = self._compute_wheel_metrics()

        wheel_feats = []
        for i, name in enumerate(WHEEL_ORDER):
            steer = self.robot._steer[name]
            speed = self.robot._speed[name]
            wheel_feats.extend(
                [
                    np.cos(steer),
                    np.sin(steer),
                    speed / max(self.robot.v_wheel_max, 1e-6),
                    margins[i],
                ]
            )

        obs = np.array(
            [
                x_B_body,
                y_B_body,
                x_R_body,
                y_R_body,
                e_psi,
                v_Bx_body,
                v_By_body,
                v_x_body,
                v_y_body,
                w_b,
                *preview_body.tolist(),
                *wheel_feats,
            ],
            dtype=np.float32,
        )
        return obs

    def _mode_proto_1(self, tangent_body: np.ndarray, steer_vecs: np.ndarray, speeds: np.ndarray) -> float:
        # Mode-1: four wheels aligned and speed-consistent, suitable for straight segments.
        tan = tangent_body / (np.linalg.norm(tangent_body) + 1e-6)
        align = float(np.mean(steer_vecs @ tan))
        steer_consistency = float(np.mean(steer_vecs @ np.mean(steer_vecs, axis=0)))
        speed_consistency = float(np.mean((speeds - np.mean(speeds)) ** 2))
        return 0.9 * align + 1.5 * steer_consistency - 1.8 * speed_consistency

    def _mode_proto_2(self, steer_angles: np.ndarray, speeds: np.ndarray) -> float:
        # Mode-2: wheel(1,2) coherent, wheel(3,4) coherent, and two groups opposite.
        g12 = wrap_to_pi(0.5 * (steer_angles[0] + steer_angles[1]))
        g34 = wrap_to_pi(0.5 * (steer_angles[2] + steer_angles[3]))
        c12 = np.cos(steer_angles[0] - steer_angles[1])
        c34 = np.cos(steer_angles[2] - steer_angles[3])
        opposite = -np.cos(wrap_to_pi(g12 - g34))
        sp12 = (speeds[0] - speeds[1]) ** 2
        sp34 = (speeds[2] - speeds[3]) ** 2
        return float(1.0 * c12 + 1.0 * c34 + 1.4 * opposite - 0.7 * (sp12 + sp34))

    def _mode_proto_3(self, steer_angles: np.ndarray, speeds: np.ndarray) -> float:
        # Placeholder extensible prototype.
        return float(0.0 - 0.05 * np.mean(speeds**2))

    def _mode_proto_4(self, steer_angles: np.ndarray, speeds: np.ndarray) -> float:
        # Placeholder extensible prototype.
        return float(0.0 - 0.05 * np.var(steer_angles))

    def _mode_gating(self) -> Tuple[float, float, float, float, np.ndarray]:
        # Dynamic gating by local future-reference heading change.
        p = self._future_ref_preview_body(steps=3).reshape(3, 2)
        d1 = p[1] - p[0]
        d2 = p[2] - p[1]
        n1 = np.linalg.norm(d1)
        n2 = np.linalg.norm(d2)
        if n1 < 1e-6:
            d1 = np.array([1.0, 0.0], dtype=np.float32)
            n1 = 1.0
        if n2 < 1e-6:
            d2 = np.array([1.0, 0.0], dtype=np.float32)
            n2 = 1.0
        d1n = d1 / n1
        d2n = d2 / n2
        turn = np.arccos(np.clip(np.dot(d1n, d2n), -1.0, 1.0))
        k = float(np.clip(turn / np.deg2rad(60.0), 0.0, 1.0))
        alpha1 = 1.0 - k
        alpha2 = k
        alpha3 = 0.1 * (1.0 - k)
        alpha4 = 0.1 * k
        z = alpha1 + alpha2 + alpha3 + alpha4 + 1e-9
        alpha1, alpha2, alpha3, alpha4 = alpha1 / z, alpha2 / z, alpha3 / z, alpha4 / z
        tangent = d1n.astype(np.float32)
        return float(alpha1), float(alpha2), float(alpha3), float(alpha4), tangent

    def _compute_reward(
        self,
        action_seq: np.ndarray,
        action_exec: np.ndarray,
        *,
        update_cache: bool = True,
    ) -> Tuple[float, Dict[str, float]]:
        geom = self._task_geometry()
        bx = geom["bx"]
        by = geom["by"]
        pos_err = float(geom["ref_pos_err"])
        vel_err = float(geom["ref_vel_err"])
        yaw_err = float(abs(wrap_to_pi(self.robot.state[2] - geom["yaw_face"])))
        w_pos = 7.5
        w_vel = 1.2
        w_yaw_huber = 5.5
        w_yaw_cos = 3.0
        w_prog_pos = 1.2
        w_prog_vel = 0.4
        w_prog_yaw = 3.0
        r_pos = -w_pos * huber_loss(pos_err, delta=0.30)
        r_vel = -w_vel * huber_loss(vel_err, delta=0.20)
        r_yaw = (
            -w_yaw_huber * huber_loss(yaw_err, delta=0.08)
            -w_yaw_cos * (1.0 - np.cos(yaw_err))
        )
        r_prog = (
            w_prog_pos * (self._prev_ref_pos_err - pos_err)
            + w_prog_vel * (self._prev_ref_vel_err - vel_err)
            + w_prog_yaw * (abs(self._prev_yaw_err) - abs(yaw_err))
        )
        r_task = r_pos + r_vel + r_yaw + r_prog

        steer_angles = np.array([self.robot._steer[n] for n in WHEEL_ORDER], dtype=np.float32)
        speeds = np.array([self.robot._speed[n] / max(self.robot.v_wheel_max, 1e-6) for n in WHEEL_ORDER], dtype=np.float32)
        steer_vecs = np.stack([np.cos(steer_angles), np.sin(steer_angles)], axis=1)
        a1, a2, a3, a4, tangent = self._mode_gating()
        mode_norm = max(a1 + a2, 1e-6)
        a1 = a1 / mode_norm
        a2 = a2 / mode_norm
        m1 = self._mode_proto_1(tangent, steer_vecs, speeds)
        m2 = self._mode_proto_2(steer_angles, speeds)
        r_mode = 0.9 * (a1 * m1 + a2 * m2)
        self._last_mode_alpha_1 = a1
        self._last_mode_alpha_2 = a2

        slip, _, sideslip, margins = self._compute_wheel_metrics()
        near_penalty = float(np.sum(np.square(np.clip(0.2 - margins, 0.0, None))))

        thr = 1.0 - self._safety_margin_ratio
        outward_penalty = 0.0
        for i, name in enumerate(WHEEL_ORDER):
            steer = self.robot._steer[name]
            if abs(steer) > thr * STEER_LIMIT:
                dsteer = float(action_exec[2 * i])
                if steer * dsteer > 0.0:
                    outward_penalty += abs(dsteer) / max(self.robot.steer_rate_max, 1e-6)

        flip_penalty = float(self.robot.last_flip_count)

        cur_sign = np.array([np.sign(self.robot._speed[n]) for n in WHEEL_ORDER], dtype=np.float32)
        sign_changed = (cur_sign != 0.0) & (self._prev_speed_sign != 0.0) & (cur_sign != self._prev_speed_sign)
        reverse_penalty = float(np.sum(sign_changed.astype(np.float32)))

        side_penalty = float(sideslip**2 + 0.5 * np.mean(slip**2))

        r_safe = (
            -0.45 * near_penalty
            -0.25 * outward_penalty
            -0.6 * flip_penalty
            -0.05 * reverse_penalty
            -0.12 * side_penalty
        )

        act_norm = np.array([
            self.robot.steer_rate_max,
            self.robot.wheel_acc_max,
            self.robot.steer_rate_max,
            self.robot.wheel_acc_max,
            self.robot.steer_rate_max,
            self.robot.wheel_acc_max,
            self.robot.steer_rate_max,
            self.robot.wheel_acc_max,
        ], dtype=np.float32)
        a0n = action_exec / np.maximum(act_norm, 1e-6)
        mag_pen = float(np.sum(a0n**2))

        da = (action_exec - self._last_exec_action) / np.maximum(act_norm, 1e-6)
        delta_pen = float(np.sum(da**2))

        seq_pen = 0.0
        for k in range(self.action_horizon - 1):
            ak = action_seq[k] / np.maximum(act_norm, 1e-6)
            ak1 = action_seq[k + 1] / np.maximum(act_norm, 1e-6)
            seq_pen += float(np.sum((ak1 - ak) ** 2))

        w_body = float(self.robot.w_body)
        yaw_acc = (w_body - self._prev_w_body) / max(self.dt, 1e-6)
        yaw_smooth_pen = float((w_body / max(self.w_max, 1e-6)) ** 2 + 0.2 * yaw_acc**2)

        r_smooth = -0.012 * mag_pen - 0.015 * delta_pen - 0.008 * seq_pen - 0.004 * yaw_smooth_pen

        total = r_task + r_mode + r_safe + r_smooth
        terms = {
            "reward_task": float(r_task),
            "reward_pos": float(r_pos),
            "reward_vel": float(r_vel),
            "reward_yaw": float(r_yaw),
            "reward_progress": float(r_prog),
            "reward_mode": float(r_mode),
            "reward_safe": float(r_safe),
            "reward_smooth": float(r_smooth),
            "flip_count": float(self.robot.last_flip_count),
            "min_margin": float(np.min(margins)),
            "ref_pos_error": float(pos_err),
            "ref_vel_error": float(vel_err),
            "pos_error": float(pos_err),
            "yaw_error": float(yaw_err),
            "mode_alpha_1": float(a1),
            "mode_alpha_2": float(a2),
            "target_x": float(bx),
            "target_y": float(by),
        }

        if update_cache:
            self._prev_ref_pos_err = pos_err
            self._prev_ref_vel_err = vel_err
            self._prev_yaw_err = yaw_err
            self._yaw_ref_prev = float(geom["yaw_face"])
            self._last_exec_action = action_exec.copy()
            self._prev_speed_sign = cur_sign
            self._prev_w_body = w_body
            self._flip_total += int(self.robot.last_flip_count)
        return float(total), terms

    def reset(
        self,
        seed: Optional[int] = None,
        options: Optional[dict] = None,
        init_state: Optional[Sequence[float]] = None,
        ref_time: Optional[float] = None,
    ) -> Tuple[np.ndarray, dict]:
        if seed is not None:
            self.seed(seed)

        if ref_time is None:
            period = _rounded_rect_perimeter() / BALL_SPEED
            ref_time = period * self.np_random.uniform(0.0, 1.0)

        context_state = self.context.reset(ref_time=ref_time)
        bx, by, bdx, bdy = context_state.reference
        speed = float(np.hypot(bdx, bdy))
        if speed > 1e-6:
            ux, uy = bdx / speed, bdy / speed
        else:
            ux, uy = 1.0, 0.0
        right_normal = np.array([uy, -ux], dtype=np.float32)

        if init_state is None:
            dist0 = self.follow_dist + self.np_random.uniform(-0.15, 0.15)
            tang_offset = self.np_random.uniform(-0.25, 0.25)
            px0 = bx + dist0 * right_normal[0] + tang_offset * ux
            py0 = by + dist0 * right_normal[1] + tang_offset * uy
            yaw0 = np.arctan2(by - py0, bx - px0)
            yaw0 += self.np_random.uniform(-0.25, 0.25)
            init_state = [px0, py0, yaw0]
        else:
            init_state = np.array(init_state, dtype=np.float32)

        self._state = State(
            robot_state=self.robot.reset(np.array(init_state, dtype=np.float32)),
            context_state=context_state,
        )
        px0, py0, yaw0 = np.array(init_state, dtype=np.float32)
        rx0 = float(bx + self.follow_dist * right_normal[0])
        ry0 = float(by + self.follow_dist * right_normal[1])
        xR_b0, yR_b0 = world_to_body(px0, py0, yaw0, rx0, ry0)
        pos_err0 = float(np.hypot(xR_b0, yR_b0) / max(self.follow_dist, 1e-6))
        c0 = np.cos(yaw0)
        s0 = np.sin(yaw0)
        v_ref_bx0 = float(c0 * bdx + s0 * bdy)
        v_ref_by0 = float(-s0 * bdx + c0 * bdy)
        vel_err0 = float(np.hypot(v_ref_bx0, v_ref_by0) / max(self.v_max, 1e-6))
        yaw_ref = np.arctan2(by - py0, bx - px0)

        # Per-reset caches required by progress/smooth/safety rewards.
        self._prev_ref_pos_err = pos_err0
        self._prev_ref_vel_err = vel_err0
        self._prev_yaw_err = float(abs(wrap_to_pi(init_state[2] - yaw_ref)))
        self._yaw_ref_prev = float(yaw_ref)
        self._last_exec_action = np.zeros(8, dtype=np.float32)
        self._prev_speed_sign = np.zeros(4, dtype=np.float32)
        self._prev_w_body = 0.0
        self._flip_total = 0
        self._last_mode_alpha_1 = 0.5
        self._last_mode_alpha_2 = 0.5
        self._elapsed_steps = 0
        self._debug_reward_terms = {}

        return self._get_obs(), self._get_info()

    def step(self, action: np.ndarray) -> Tuple[np.ndarray, float, bool, dict]:
        # Required step flow:
        # 1) receive 24D action
        # 2) reshape to (3, 8)
        # 3) execute only first action
        # 4) robot applies traditional steering-limit safety shell
        # 5) update context
        # 6) update env state
        # 7) compute reward
        # 8) return obs, reward, done, info
        action_seq, action_exec = self._split_action(action)

        robot_state_next = self.robot.step(action_exec)
        context_state_next = self.context.step()
        self._state = State(robot_state=robot_state_next, context_state=context_state_next)

        self._elapsed_steps += 1
        reward, terms = self._compute_reward(action_seq, action_exec, update_cache=True)
        terminated = self._get_terminated()
        if terminated:
            reward -= self.termination_penalty
        self._debug_reward_terms = terms

        obs = self._get_obs()
        info = self._get_info()
        info.update(terms)
        info["flip_total"] = int(self._flip_total)
        info["elapsed_steps"] = int(self._elapsed_steps)
        return obs, reward, terminated, info

    def _get_reward(self, action: np.ndarray) -> float:
        # Unused because step() is overridden to follow the required sequence.
        action_seq, action_exec = self._split_action(action)
        reward, _ = self._compute_reward(action_seq, action_exec, update_cache=False)
        return reward

    def _get_terminated(self) -> bool:
        px, py = self.robot.state[:2]
        bx, by = self.context.state.reference[:2]
        dist_to_ball = np.hypot(px - bx, py - by)
        timeout = self._elapsed_steps >= self.max_episode_steps
        out_of_range = dist_to_ball > 6.0
        return bool(timeout or out_of_range)

    def render(self, mode: str = "human"):
        import matplotlib.pyplot as plt
        import matplotlib.patches as pc

        plt.ion()
        fig = plt.figure(num=0, figsize=(6.4, 6.4))
        plt.clf()
        px, py, yaw = self.robot.state
        bx, by, bdx, bdy = self.context.state.reference
        rx, ry = compute_scan_follow_target(bx, by, bdx, bdy, self.follow_dist)

        ax = plt.axes(xlim=(px - 4, px + 4), ylim=(py - 4, py + 4))
        ax.set_aspect("equal")

        veh_length = 0.48
        veh_width = 0.35
        x_offset = veh_length / 2.0 * np.cos(yaw) - veh_width / 2.0 * np.sin(yaw)
        y_offset = veh_length / 2.0 * np.sin(yaw) + veh_width / 2.0 * np.cos(yaw)
        ax.add_patch(
            pc.Rectangle(
                (px - x_offset, py - y_offset),
                veh_length,
                veh_width,
                angle=np.rad2deg(yaw),
                facecolor="w",
                edgecolor="r",
                zorder=2,
            )
        )

        wheel_len = 0.08
        wheel_rad = 0.025
        for name in WHEEL_ORDER:
            x_i, y_i = WHEEL_POS[name]
            steer = self.robot._steer[name]
            wx = px + np.cos(yaw) * x_i - np.sin(yaw) * y_i
            wy = py + np.sin(yaw) * x_i + np.cos(yaw) * y_i
            theta = yaw + steer
            dx = 0.5 * wheel_len * np.cos(theta)
            dy = 0.5 * wheel_len * np.sin(theta)
            ax.add_patch(pc.Circle((wx, wy), radius=wheel_rad, color="k", zorder=4))
            ax.plot([wx - dx, wx + dx], [wy - dy, wy + dy], color="k", linewidth=2, zorder=5)

        ax.add_patch(pc.Circle((bx, by), radius=0.05, color="red", zorder=3))
        ax.plot([rx], [ry], marker="x", color="blue", zorder=3)

        ax.set_title("ToRwheelsim Seq-Scan RL Env")
        ax.grid(True)
        plt.tight_layout()

        if mode == "rgb_array":
            fig.canvas.draw()
            image_from_plot = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
            image_from_plot = image_from_plot.reshape(fig.canvas.get_width_height()[::-1] + (3,))
            plt.pause(0.01)
            return image_from_plot
        if mode == "human":
            plt.pause(0.01)
            plt.show(block=False)


def env_creator(**kwargs):
    return ToRwheelsimSeqScanEnv(**kwargs)


# Compared with env_ToRwheelsim.py:
# 1) task target changed: right-side follow point + heading to the moving target;
# 2) action changed from single-step 8D to 3-step sequence 24D (execute first step only);
# 3) reward changed to task + mode + safety + smooth structure;
# 4) added mode-layer reward with dynamic gating by future trajectory geometry;
# 5) kept traditional steering-limit flip logic as a safety shell, while penalizing over-reliance.
